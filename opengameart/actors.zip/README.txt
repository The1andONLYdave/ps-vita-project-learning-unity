Inside you will find animated actors from the PlatForge project: 
https://play.google.com/store/apps/details?id=edu.elon.honors.price.maker

The "heroes" are asymmetrical and contain a special jump animation, while the "monsters" have only symmetrical walk and attack animations.

In each folder you will find and animation preview jar, which you can run if you have java on your computer. Upon opening, the program will request a file. Provide it with one of the actors from its folder (the hero and monster animators are different, so make sure its the right folder). The previewer will then allow you so see how the actor animated.

All art in this package is licensed under the Creative Commons 3.0 Attribution/Share-Alike license:
http://creativecommons.org/licenses/by-sa/3.0/

The original artists for this work include:
Summer Thaxton, Hannah Cohen and Stafford McIntyre